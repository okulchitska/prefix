import sys
from cx_Freeze import setup,Executable

setup(
    name = "CMJFESync",
    version = '1.0',
    description = "Used to Download files from server",
    executables = [Executable("CMJFESync.py",base = 'win32GUI')]
)