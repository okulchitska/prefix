#!/usr/local/bin/python2.7
# encoding: utf-8
'''
aafpsgsync -- a simple replication tool for JFE
aafpsgsync is a simple tool to copy the Latest version of the JFE to a local disk
@author:     Sanjeeth Nayak
@copyright:  2018 Amadeus Services Limited. All rights reserved.
@license:    Apache License 2.0
@contact:    sanjeeth.sanjeeth@amadeus.com
@deffield    updated: 2/2/2013
'''

from zipfile import ZipFile
import os

try:
    ServerPath = open("ServerPath.txt",'r').readline()
    DesiredJFEVersion = open("DesiredJFEVersion.cfg", 'r').readline()

    zip_ref = ZipFile(ServerPath + '\\' + DesiredJFEVersion, 'r')

    if not os.path.exists('CurrentJFEVersion.cfg'):
        temp = open(r"CurrentJFEVersion.cfg", 'w')
        temp.close
    CurrentJFEVersion = open("CurrentJFEVersion.cfg", 'r').readline()

    if not DesiredJFEVersion == CurrentJFEVersion:
        #os.rename('LatestCMBuild','OldCMBuild')
        #os.mkdir(r'LatestCMBuild')
        zip_ref.extractall(r'LatestCMBuild')

    open(r"DownloadComplete.txt", 'w')
    open(r"CurrentJFEVersion.cfg", 'w').write(DesiredJFEVersion)
except:
    open(r"Unexpected Error", 'w')